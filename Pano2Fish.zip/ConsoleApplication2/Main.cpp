#include "opencv2/core/core.hpp"
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <direct.h>
#include <iostream>
#include <fstream>
#include <iterator>  
#include <vector> 
#include <io.h>
#define PI 3.1415926535897932384

using namespace cv;

void pano2fish_GTSF(Mat panoImgInput, std::string panoGtPath, Mat fishImgOutput, std::string fishImgGtSFSavePath, std::string fishGtSFSavePath) {
	std::ifstream inCor(panoGtPath);
	int lineNo = 1;
	std::string gtCorEven;
	float f_fish = fishImgOutput.cols / 2;
	std::ofstream fishGTFile(fishGtSFSavePath, std::ios::out);
	if (!fishGTFile) {
		std::cout << "Open Failed!" << std::endl;
	}
	if (!inCor.is_open())
	{
		std::cout << "Read Failed!" << std::endl;
	}
	else
	{
		while (std::getline(inCor, gtCorEven)) {
			if (lineNo % 2 != 0)
			{
				lineNo++;
				continue;
			}
			std::istringstream ss(gtCorEven.c_str());
			char a1[5], a2[5], a3[5];
			ss >> a1 >> a2 >> a3;
			std::string u_pano = a1;
			std::string v_pano = a2;
			float phi_pano = (panoImgInput.rows - std::atof(v_pano.c_str())) / panoImgInput.rows * PI * 6 / 8;
			float theta_pano = (std::atof(u_pano.c_str()) / panoImgInput.cols) * 2 * PI;
			float R_fish = f_fish * sin(phi_pano);
			float i_fish = R_fish * sin(theta_pano);
			float j_fish = sqrt(R_fish * R_fish - i_fish * i_fish);
			j_fish = theta_pano < PI / 2 || theta_pano >3 * PI / 2 ? -j_fish : j_fish;

			cv::Point2f point;
			point.x = i_fish + f_fish;
			point.y = j_fish + f_fish;
			cv::circle(fishImgOutput, point, 8, cv::Scalar(0, 0, 255), -1);
			fishGTFile << (int)round(point.x);
			fishGTFile << " ";
			fishGTFile << (int)round(point.y);
			fishGTFile << "\n";
			lineNo++;
		}
		fishGTFile.close();
		waitKey(0);
		cv::imwrite(fishImgGtSFSavePath, fishImgOutput);
	}
}

void pano2fish_GT(Mat panoImgInput, std::string panoGtPath, Mat fishImgOutput, std::string fishImgGtSavePath, std::string fishGtSavePath) {
	std::ifstream inCor(panoGtPath);
	int lineNo = 1;
	std::string gtCorEven;
	float f_fish = fishImgOutput.cols / 2;
	std::ofstream fishGTFile(fishGtSavePath, std::ios::out);
	if (!fishGTFile) {
		std::cout << "Open Failed!" << std::endl;
	}
	if (!inCor.is_open())
	{
		std::cout << "Read Failed!" << std::endl;
	}
	else
	{
		while (std::getline(inCor, gtCorEven)) {
			if (lineNo % 2 != 0)
			{
				lineNo++;
				continue;
			}
			std::istringstream ss(gtCorEven.c_str());
			char a1[5], a2[5], a3[5];
			ss >> a1 >> a2 >> a3;
			std::string u_pano = a1;
			std::string v_pano = a2;
			float phi_pano = (panoImgInput.rows - std::atof(v_pano.c_str())) / panoImgInput.rows * PI * 8 / 8;
			float theta_pano = (std::atof(u_pano.c_str()) / panoImgInput.cols) * 2 * PI;
			float R_fish = f_fish * sin(phi_pano);
			float i_fish = R_fish * sin(theta_pano);
			float j_fish = sqrt(R_fish * R_fish - i_fish * i_fish);
			j_fish = theta_pano < PI / 2 || theta_pano >3 * PI / 2 ? -j_fish : j_fish;

			cv::Point2f point;
			point.x = i_fish + f_fish;
			point.y = j_fish + f_fish;
			cv::circle(fishImgOutput, point, 8, cv::Scalar(0, 255, 0), -1);
			fishGTFile << (int)round(point.x);
			fishGTFile << " ";
			fishGTFile << (int)round(point.y);
			fishGTFile << "\n";
			lineNo++;
		}
		fishGTFile.close();
		waitKey(0);
		cv::imwrite(fishImgGtSavePath, fishImgOutput);
	}
}



void Fish2Pano() {
	std::string fishpath = "D:/tmp/img_fish.png";   //����ͼ·��
	Mat fishImg = imread(fishpath);
	Mat panoImg = Mat(512, 1024, CV_8UC3);   //����ȫ��ͼ
	float theta = 0, phi = 0;
	float f = panoImg.rows / PI;
	f *= 8;
	float R = 0, row = 0, col = 0;
	resize(fishImg, fishImg, Size(f * 2, f * 2), 0, 0, INTER_LINEAR);
	for (int i = panoImg.rows/3; i < panoImg.rows; i++) {   //��
		for (int j = 0; j < panoImg.cols; j++) {
			theta = 8 * j / f;
			phi = (panoImg.rows - i) * 6 / f;
			R = f * sin(phi);
			col = R * sin(PI - theta);
			row = R * cos(PI - theta);
			row = min(row + f, 2 * f-1);
			col = min(col + f, 2 * f-1);
			
			/*Խ�紦��*/
			if (row < f && col < f && (f - row)*(f - row) + (f - col)*(f - col) >= (f-2) * (f-2)) {
				panoImg.at<Vec3b>(i, j) = { 0,0,0 };
				continue;
			}
			if (row < f && col > f && (f - row)*(f - row) + (col - f)*(col-f) >= (f - 2) * (f - 2)) {
				panoImg.at<Vec3b>(i, j) = { 0,0,0 };
				continue;
			}
			if (row > f && col < f && (row - f)*(row - f) + (f - col)*(f - col) >= (f - 2) * (f - 2)) {
				panoImg.at<Vec3b>(i, j) = { 0,0,0 };
				continue;
			}
			if (row > f && col > f && (row - f)*(row - f) + (col - f)*(col - f) >= (f - 2) * (f - 2)) {
				panoImg.at<Vec3b>(i, j) = { 0,0,0 };
				continue;
			}
			panoImg.at<Vec3b>(i, j) = fishImg.at<Vec3b>(row, col);
		}
	}
	resize(panoImg, panoImg, Size(1024, 512), 0, 0, INTER_LINEAR);
	imwrite("D:/tmp/haha.png", panoImg);
}

//MengMing-20210310 ����ͼתȫ��ͼ
void Fish2Pano(std::string Path, std::string panoPath) {
	std::string fishpath = Path + "\\" + panoPath;   //����ͼ·��
	Mat fishImg = imread(fishpath);
	Mat panoImg = Mat(512, 1024, CV_8UC3);   //����ȫ��ͼ
	float theta = 0, phi = 0;
	float f = panoImg.rows / PI;
	f *= 8;
	float R = 0, row = 0, col = 0;
	resize(fishImg, fishImg, Size(f * 2, f * 2), 0, 0, INTER_LINEAR);
	for (int i = panoImg.rows / 3; i < panoImg.rows; i++) {   //��
		for (int j = 0; j < panoImg.cols; j++) {
			theta = 8 * j / f;
			phi = (panoImg.rows - i) * 6 / f;
			R = f * sin(phi);
			col = R * sin(PI - theta);
			row = R * cos(PI - theta);
			row = min(row + f, 2 * f - 1);
			col = min(col + f, 2 * f - 1);

			/*Խ�紦��*/
			if (row < f && col < f && (f - row)*(f - row) + (f - col)*(f - col) >= (f - 2) * (f - 2)) {
				panoImg.at<Vec3b>(i, j) = { 0,0,0 };
				continue;
			}
			if (row < f && col > f && (f - row)*(f - row) + (col - f)*(col - f) >= (f - 2) * (f - 2)) {
				panoImg.at<Vec3b>(i, j) = { 0,0,0 };
				continue;
			}
			if (row > f && col < f && (row - f)*(row - f) + (f - col)*(f - col) >= (f - 2) * (f - 2)) {
				panoImg.at<Vec3b>(i, j) = { 0,0,0 };
				continue;
			}
			if (row > f && col > f && (row - f)*(row - f) + (col - f)*(col - f) >= (f - 2) * (f - 2)) {
				panoImg.at<Vec3b>(i, j) = { 0,0,0 };
				continue;
			}
			panoImg.at<Vec3b>(i, j) = fishImg.at<Vec3b>(row, col);
		}
	}
	resize(panoImg, panoImg, Size(1024, 512), 0, 0, INTER_LINEAR);
	std::string root = "E:\\tmp\\F-P-PanoContext\\train\\img\\";
	std::string target = root + panoPath;
	std::cout << target << std::endl;
	imwrite(target, panoImg);


}

//ȫ��ͼת����ͼ
void Pano2Fish(std::string Path, std::string panoPath) {
	volatile float theta = 0, phi = 0;
	//ȫ��ͼ·��    
	float f;
	//std::string panoPath = "D:/tmp/img.png";
	Mat panoImgInput = imread(Path + "\\" + panoPath);
	//fֵΪȫ��ͼ��һ����ֵ�ĸ߶�
	f = panoImgInput.rows / PI;
	f *= 8;
	int min = 0;
	//���ɵ�����ͼ��RGB3ͨ��ͼ��
	Mat fishImgOutput = Mat(Size(f * 2, f * 2), CV_8UC3);
	for (int i = -f; i <= f; i++) {
		for (int j = -f; j <= f; j++) {
			float R = sqrt(i*i + j*j);
			if (R >= f) {
				fishImgOutput.at<Vec3b>(i + f, j + f) = { 0, 0, 0 };
			}
			else {
				theta = R == 0 ? 0 : asin(j / R);
				if (i > 0) {
					theta = theta > 0 ? PI - theta : -PI - theta;
				}
				//orthographic projection (fisheye)-- R = f * sin(phi)
				phi = asin(R / f);
				int row = panoImgInput.rows - 1 - phi*f / 6;
				int col = theta*f / 8;
				fishImgOutput.at<Vec3b>(i + f, j + f) = panoImgInput.at<Vec3b>(row, col);
			}

		}
	}

	resize(fishImgOutput, fishImgOutput, Size(1024, 1024), 0, 0, INTER_LINEAR);
	std::string root = "D:\\dataset\\Structured3D\\Fish\\noncuboid\\test\\img\\";
	std::string target = root + panoPath;
	std::cout << target << std::endl;
	imwrite(target, fishImgOutput);
}



//ȫ�����ͼת�������ͼ(16bit)
void Pano2Fish_16bit(std::string Path, std:: string panoPath) {
	volatile float theta = 0, phi = 0;
	//ȫ��ͼ·��    
	float f;
	/*std::string panoPath = "D:/tmp/depth.png";*/
	
	Mat panoImgInput = imread(Path+"\\"+panoPath, 2);
	//fֵΪȫ��ͼ��һ����ֵ�ĸ߶�
	f = panoImgInput.rows / PI;
	f *= 8;
	int min = 0;
	//���ɵ�����ͼ��RGB3ͨ��ͼ��
	Mat fishImgOutput = Mat(Size(f * 2, f * 2), CV_16UC1);
	for (int i = -f; i <= f; i++) {
		for (int j = -f; j <= f; j++) {
			float R = sqrt(i*i + j*j);
			if (R >= f) {
				// ���Ӧ����0  instanceӦ����65535
				fishImgOutput.at<ushort>(i + f, j + f) = 0;
			}
			else {
				theta = R == 0 ? 0 : asin(j / R);
				if (i > 0) {
					theta = theta > 0 ? PI - theta : -PI - theta;
				}
				//orthographic projection (fisheye)-- R = f * sin(phi)
				phi = asin(R / f);
				int row = panoImgInput.rows - 1 - phi*f / 6;
				int col = theta*f / 8;
				fishImgOutput.at<ushort>(i + f, j + f) = panoImgInput.at<ushort>(row, col);
			}
		}
	}
	resize(fishImgOutput, fishImgOutput, Size(1024, 1024), 0, 0, INTER_LINEAR);
	std::vector<int> compression_params;
	compression_params.push_back(CV_IMWRITE_PNG_COMPRESSION);
	compression_params.push_back(0);
	std::string root = "D:\\dataset\\Depth+RGB\\noncuboid6\\valid\\emptydepth\\";
	std::string target = root + panoPath;
	std::cout << target << std::endl;
	imwrite(target, fishImgOutput, compression_params);
}


void getFiles1(std::string path, std::vector<std::string>& files)
{
	//�ļ����  
	//long hFile = 0;  //win7    
	intptr_t hFile = 0;   //win10
	//�ļ���Ϣ  
	struct _finddata_t fileinfo;
	std::string p;
	if ((hFile = _findfirst(p.assign(path).append("\\*").c_str(), &fileinfo)) != -1)      // "\\*"��ָ��ȡ�ļ����µ��������͵��ļ��������ȡ�ض����͵��ļ�����pngΪ�������á�\\*.png��
	{
		do
		{
			//�����Ŀ¼,����֮  
			//�������,�����б�  
			if ((fileinfo.attrib &  _A_SUBDIR))
			{
				if (strcmp(fileinfo.name, ".") != 0 && strcmp(fileinfo.name, "..") != 0)
					getFiles1(p.assign(path).append("\\").append(fileinfo.name), files);
			}
			else
			{
				//files.push_back(path + "\\" + fileinfo.name);
				files.push_back(fileinfo.name);
			}
		} while (_findnext(hFile, &fileinfo) == 0);
		_findclose(hFile);
	}
}


int main(int argc, char** argv) {
	//Pano2Fish_16bit();
	
	
	//std::string Path = "D:\\dataset\\Depth+RGB\\noncuboid6\\valid\\emptydepth_pano\\";
	std::string FPath = "D:\\dataset\PanoContext\train\img\\";
	std::vector<std::string> files;
	getFiles1(FPath, files);
	for (int i = 0; i < files.size(); i++) {
		//std::cout << files[i] << std::endl;
		std::cout << FPath + "\\" + files[i] << std::endl;
		//Pano2Fish_16bit(Path, files[i]);
		// MengMing-20120310 �������ݼ�������ת��ȫ��
		Fish2Pano(FPath, files[i]);
	}

		

		
	//getchar();
	//system("pause");
	return 0;




	//Mat panoImgInput;
	//float f;
	//volatile  float theta = 0, phi = 0;
	//Mat fishImgOutput;
	//std::string panoGtPath;
	//std::string panoPath = "E:/tmp/img.png";
	//panoImgInput = imread(panoPath);
	////f��Ϊȫ��ͼ��һ���ȶ�Ӧ�ĸ߶�
	//f = panoImgInput.rows / PI;
	//f *= 8;
	//int min = 0;
	//fishImgOutput = Mat(Size(f * 2, f * 2), CV_8UC3);
	//for (int i = -f; i <= f; i++) {
	//	for (int j = -f; j <= f; j++) {
	//		float R = sqrt(j*j + i*i);
	//		if (R >= (f)) {
	//			fishImgOutput.at<Vec3b>(i + f, j + f) = { 0,0,0 };
	//		}
	//		else {
	//			theta = R == 0 ? 0 : asin(j / R);
	//			if (i > 0) {
	//				theta = theta > 0 ? PI - theta :  -PI - theta;
	//			}
	//			//orthographic projection (fisheye)-- R = f * sin(phi)
	//			phi = asin(R / f);
	//			int row = panoImgInput.rows-1 - phi * f / 6;
	//			int col = theta * f / 8;
	//			//�õ���Ӧ������
	//			/*if (int((i + f)*(1023/(2*f-1))) == 250 && int((j + f)*(1023 / (2 * f - 1))) == 734) {
	//				std::cout << row << "   " << col << std::endl;
	//			}*/
	//			fishImgOutput.at<Vec3b>(i + f, j + f) = panoImgInput.at<Vec3b>(row, col);
	//		}
	//	}
	//}
	//getchar();
	//resize(fishImgOutput, fishImgOutput, Size(1024, 1024), 0, 0, INTER_LINEAR);
	//imwrite("E:/tmp/1_fish.png", fishImgOutput);
}
